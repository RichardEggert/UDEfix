from PyQt5.QtWidgets import *

from fixpointtool.content.fpt_mapping import FPTMapping


class QDMListWidgetItem(QListWidgetItem):
    def __init__(self, item, itemType, tupleType=None, setType=None, parent=None):
        super().__init__(parent)
        self.item = item
        self.type = itemType
        self.tupleType = tupleType
        self.setType = setType

        if self.type == "string":
            self.setText(self.item)
        elif self.type == "number":
            self.setText(str(self.item))
        elif self.type == "2-tuple":
            if type(self.item[0]) == set or type(self.item[0]) == frozenset:
                newStr1 = "{"
                for elem in sorted(self.item[0]):
                    newStr1 += str(elem) + ", "
                if len(newStr1) > 1:
                    newStr1 = newStr1[:-2] + "}"
                else:
                    newStr1 = "{}"

                newStr2 = "{"
                for elem in sorted(self.item[1]):
                    newStr2 += str(elem) + ", "
                if len(newStr2) > 1:
                    newStr2 = newStr2[:-2] + "}"
                else:
                    newStr2 = "{}"

                newStr = "(" + newStr1 + ", " + newStr2 + ")"
                self.setText(newStr)
            elif type(self.item[0]) == FPTMapping:
                self.setText("(" + self.item[0].name + ", " + self.item[1].name + ")")
            else:
                self.setText(str(self.item))
        elif self.type == "set" or self.type == "power set":
            isSetOfFunctions = False
            for elem in self.item:
                isSetOfFunctions = type(elem) == FPTMapping
                break

            if isSetOfFunctions:
                newStr = "{"
                for elem in sorted(self.item, key=lambda mapping: mapping.name):
                    newStr += elem.name + ", "
                if len(newStr) > 1:
                    newStr = newStr[:-2] + "}"
                else:
                    newStr = "{}"
            else:
                newStr = "{"
                for elem in sorted(self.item):
                    newStr += str(elem) + ", "
                if len(newStr) > 1:
                    newStr = newStr[:-2] + "}"
                else:
                    newStr = "{}"

            self.setText(newStr)
        elif self.type == "mapping":
            self.setText(self.item.name)
        else:
            self.setText("ERROR")

    def overwriteText(self):
        if self.type == "string":
            self.setText(self.item)
        elif self.type == "number":
            self.setText(str(self.item))
        elif self.type == "2-tuple":
            if type(self.item[0]) == set or type(self.item[0]) == frozenset:
                newStr1 = "{"
                for elem in sorted(self.item[0]):
                    newStr1 += str(elem) + ", "
                if len(newStr1) > 1:
                    newStr1 = newStr1[:-2] + "}"
                else:
                    newStr1 = "{}"

                newStr2 = "{"
                for elem in sorted(self.item[1]):
                    newStr2 += str(elem) + ", "
                if len(newStr2) > 1:
                    newStr2 = newStr2[:-2] + "}"
                else:
                    newStr2 = "{}"

                newStr = "(" + newStr1 + ", " + newStr2 + ")"
                self.setText(newStr)
            elif type(self.item[0]) == FPTMapping:
                self.setText("(" + self.item[0].name + ", " + self.item[1].name + ")")
            else:
                self.setText(str(self.item))
        elif self.type == "set" or self.type == "power set":
            isSetOfFunctions = False
            for elem in self.item:
                isSetOfFunctions = type(elem) == FPTMapping
                break

            if isSetOfFunctions:
                newStr = "{"
                for elem in sorted(self.item, key=lambda mapping: mapping.name):
                    newStr += elem.name + ", "
                if len(newStr) > 1:
                    newStr = newStr[:-2] + "}"
                else:
                    newStr = "{}"
            else:
                newStr = "{"
                for elem in sorted(self.item):
                    newStr += str(elem) + ", "
                if len(newStr) > 1:
                    newStr = newStr[:-2] + "}"
                else:
                    newStr = "{}"

            self.setText(newStr)
        elif self.type == "mapping":
            self.setText(self.item.name)
        else:
            self.setText("ERROR")