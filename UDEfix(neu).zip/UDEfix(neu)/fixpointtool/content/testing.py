from fixpointtool.content.fpt_set import FPTSet
from fixpointtool.content.fpt_tuple import FPTTuple

if __name__ == '__main__':

    y = FPTSet([2, 1, 3, 5])
    x = FPTSet([1, 2, 3])

    print(x <= y)
